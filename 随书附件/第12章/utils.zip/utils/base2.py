import time

def get_timestamp_string():
    """返回当天（执行日期）的日期字符串，格式为YYYYMMDDHHMMSS"""
    return time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))