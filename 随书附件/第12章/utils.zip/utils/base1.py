from tempfile import TemporaryDirectory

def mk_tmp_dir():
    with TemporaryDirectory() as tmp_dir:
        return tmp_dir